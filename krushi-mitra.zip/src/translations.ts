export const translations = {
  English: {
    title: "Krushi Mitra",
    online: "Online",
    welcome: "Namaste 🙏 Farmer!",
    subtitle: "I am Krushi Mitra AI",
    description: "Take a photo of your crop for diagnostics.",
    quickTools: "Quick Tools",
    cropScan: "Crop Scan",
    voiceAi: "Voice AI",
    weather: "Weather",
    schemes: "Schemes",
    history: "Recent Activity",
    viewAll: "History",
    navHome: "Home",
    navVoice: "Voice",
    navScan: "SCAN",
    navWeather: "Weather",
    navScheme: "Scheme",
    login: "Tap to Login",
    logout: "Logout",
    analyzing: "Analyzing...",
    diagnosticResult: "Diagnostic Result",
    aiAnalysis: "AI Analysis Complete",
    gotIt: "Got it",
    listening: "Listening...",
    askAdvice: "How to treat leaf spot?",
    weatherSunny: "Sunny",
    weatherRain: "Rain",
    weatherWind: "Wind",
    weatherHumid: "Humidity",
    schemesTitle: "Schemes for you",
    supportedCrops: "Supported Crops",
    readAloud: "Listen to Advice",
    stopReading: "Stop Listening",
    findNearby: "Find Nearby Expert Center",
    cropCare: "Crop Care",
    schemesList: [
      { 
        title: "PM-KISAN", 
        desc: "Direct benefit transfer of ₹6,000 per year to small and marginal farmers.", 
        url: "https://pmkisan.gov.in/",
        tag: "General"
      },
      { 
        title: "PM Fasal Bima Yojana", 
        desc: "Protect your crops against natural calamities with minimal premium.", 
        url: "https://pmfby.gov.in/",
        tag: "Crop Insurance"
      },
      { 
        title: "Kisan Credit Card (KCC)", 
        desc: "Easy access to short-term loans for your production needs and crops.", 
        url: "https://www.myscheme.gov.in/schemes/kcc",
        tag: "Loans"
      },
      { 
        title: "Soil Health Card", 
        desc: "Get your soil tested and optimize fertilizer use for better yield.", 
        url: "https://soilhealth.dac.gov.in/",
        tag: "Soil Care"
      }
    ]
  },
  ಕನ್ನಡ: {
    title: "ಕೃಷಿ ಮಿತ್ರ",
    online: "ಆನ್‌ಲೈನ್",
    welcome: "ನಮಸ್ತೆ 🙏 ರೈತ ಬಾಂಧವರೇ!",
    subtitle: "ನಾನು ಕೃಷಿ ಮಿತ್ರ AI",
    description: "ರೋಗ ಪತ್ತೆಹಚ್ಚಲು ನಿಮ್ಮ ಬೆಳೆಯ ಫೋಟೋ ತೆಗೆಯಿರಿ.",
    quickTools: "ತ್ವರಿತ ಪರಿಕರಗಳು",
    cropScan: "ಬೆಳೆ ತಪಾಸಣೆ",
    voiceAi: "ಧ್ವನಿ AI",
    weather: "ಹವಾಮಾನ",
    schemes: "ಯೋಜನೆಗಳು",
    history: "ಇತ್ತೀಚಿನ ಚಟುವಟಿಕೆ",
    viewAll: "ಇತಿಹಾಸ",
    navHome: "ಮನೆ",
    navVoice: "ಧ್ವನಿ",
    navScan: "ಸ್ಕ್ಯಾನ್",
    navWeather: "ಹವಾಮಾನ",
    navScheme: "ಯೋಜನೆ",
    login: "ಲಾಗಿನ್ ಮಾಡಿ",
    logout: "ಲಾಗ್ ಔಟ್",
    analyzing: "ವಿಶ್ಲೇಷಿಸಲಾಗುತ್ತಿದೆ...",
    diagnosticResult: "ಪರಿಶೀಲನಾ ಫಲಿತಾಂಶ",
    aiAnalysis: "AI ವಿಶ್ಲೇಷಣೆ ಪೂರ್ಣಗೊಂಡಿದೆ",
    gotIt: "ಸರಿ",
    listening: "ಕೇಳಿಸಿಕೊಳ್ಳುತ್ತಿದೆ...",
    askAdvice: "ಎಲೆ ಚುಕ್ಕೆ ರೋಗಕ್ಕೆ ಮದ್ದೇನು?",
    weatherSunny: "ಬಿಸಿಲು",
    weatherRain: "ಮಳೆ",
    weatherWind: "ಗಾಳಿ",
    weatherHumid: "ತೇವಾಂಶ",
    schemesTitle: "ನಿಮಗಾಗಿ ಯೋಜನೆಗಳು",
    supportedCrops: "ಬಾಧಿತ ಬೆಳೆಗಳು",
    readAloud: "ಸಲಹೆ ಕೇಳಿ",
    stopReading: "ನಿಲ್ಲಿಸಿ",
    findNearby: "ಹತ್ತಿರದ ಕೃಷಿ ಕೇಂದ್ರ ಹುಡುಕಿ",
    cropCare: "ಕೃಷಿ ಕೇಂದ್ರ",
    schemesList: [
      { 
        title: "ಪಿಎಂ-ಕಿಸಾನ್", 
        desc: "ಸಣ್ಣ ಮತ್ತು ಅಲ್ಪ ಭೂಹಿಡುವಳಿ ರೈತರಿಗೆ ವಾರ್ಷಿಕ ₹6,000 ನೇರ ನಗದು ನೆರವು.", 
        url: "https://pmkisan.gov.in/",
        tag: "ಸಾಮಾನ್ಯ"
      },
      { 
        title: "ಪಿಎಂ ಫಸಲ್ ಬಿಮಾ ಯೋಜನೆ", 
        desc: "ನೈಸರ್ಗಿಕ ವಿಕೋಪಗಳ ವಿರುದ್ಧ ನಿಮ್ಮ ಬೆಳೆಗಳಿಗೆ ವಿಮಾ ರಕ್ಷಣೆ ಪಡೆಯಿರಿ.", 
        url: "https://pmfby.gov.in/",
        tag: "ಬೆಳೆ ವಿಮೆ"
      },
      { 
        title: "ಕಿಸಾನ್ ಕ್ರೆಡಿಟ್ ಕಾರ್ಡ್", 
        desc: "ಬೆಳೆ ಉತ್ಪಾದನೆಗೆ ಅಗತ್ಯವಿರುವ ಅಲ್ಪಾವಧಿ ಸಾಲ ಸೌಲಭ್ಯ.", 
        url: "https://www.myscheme.gov.in/schemes/kcc",
        tag: "ಸಾಲಗಳು"
      },
      { 
        title: "ಸಾಯಿಲ್ ಹೆಲ್ತ್ ಕಾರ್ಡ್", 
        desc: "ಮಣ್ಣಿನ ತಪಾಸಣೆ ಮಾಡಿ, ಉತ್ತಮ ಫಸಲಿಗಾಗಿ ರಸಗೊಬ್ಬರ ಬಳಕೆಯನ್ನು ಸುಧಾರಿಸಿ.", 
        url: "https://soilhealth.dac.gov.in/",
        tag: "ಮಣ್ಣಿನ ಆರೋಗ್ಯ"
      }
    ]
  },
  हिंदी: {
    title: "कृषि मित्र",
    online: "ऑनलाइन",
    welcome: "नमस्ते 🙏 किसान भाई!",
    subtitle: "मैं हूँ कृषि मित्र AI",
    description: "बीमारी की पहचान के लिए अपनी फसल की फोटो लें।",
    quickTools: "त्वरित उपकरण",
    cropScan: "फसल जाँच",
    voiceAi: "वॉयस AI",
    weather: "मौसम",
    schemes: "योजनाएं",
    history: "हाल की गतिविधि",
    viewAll: "इतिहास",
    navHome: "मुख्य",
    navVoice: "आवाज़",
    navScan: "स्कैन",
    navWeather: "मौसम",
    navScheme: "योजना",
    login: "लॉगिन करें",
    logout: "लॉगआउट",
    analyzing: "विश्लेषण हो रहा है...",
    diagnosticResult: "जांच का परिणाम",
    aiAnalysis: "AI विश्लेषण पूरा हुआ",
    gotIt: "समझ गए",
    listening: "सुन रहा हूँ...",
    askAdvice: "पत्ती के धब्बों का इलाज क्या है?",
    weatherSunny: "धूप",
    weatherRain: "बारिश",
    weatherWind: "हवा",
    weatherHumid: "नमी",
    schemesTitle: "आपके लिए योजनाएं",
    supportedCrops: "समर्थित फसलें",
    readAloud: "सलाह सुनें",
    stopReading: "सुनना बंद करें",
    findNearby: "नजदीकी कृषि केंद्र खोजें",
    cropCare: "कृषि केंद्र",
    schemesList: [
      { 
        title: "पीएम-किसान", 
        desc: "छोटे और सीमांत किसानों को प्रति वर्ष ₹6,000 की सीधी नकद सहायता।", 
        url: "https://pmkisan.gov.in/",
        tag: "सामान्य"
      },
      { 
        title: "पीएम फसल बीमा योजना", 
        desc: "न्यूनतम प्रीमियम के साथ प्राकृतिक आपदाओं के खिलाफ अपनी फसलों का बीमा करें।", 
        url: "https://pmfby.gov.in/",
        tag: "फसल बीमा"
      },
      { 
        title: "किसान क्रेडिट कार्ड", 
        desc: "खेती की जरूरतों और फसलों के लिए अल्पकालिक ऋण का आसान उपयोग।", 
        url: "https://www.myscheme.gov.in/schemes/kcc",
        tag: "कर्ज"
      },
      { 
        title: "मृदा स्वास्थ्य कार्ड", 
        desc: "मिट्टी की जांच कराएं और बेहतर पैदावार के लिए उर्वरक के उपयोग को सुधारें।", 
        url: "https://soilhealth.dac.gov.in/",
        tag: "मिट्टी देखभाल"
      }
    ]
  }
};
