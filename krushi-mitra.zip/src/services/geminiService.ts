import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function analyzeCrop(base64Image: string, language: string = "English") {
  const model = "gemini-3-flash-preview";
  const prompt = `You are a very kind and respectful Krushi Mitra (Agri Friend). 
  Analyze this crop image and provide a VERY SIMPLE, clear, and polite response strictly in ${language}.
  
  IMPORTANT: Use ${language} ONLY. If the language is Kannada or Hindi, use that script.
  
  Structure your response like this:
  1. **Greeting**: A warm, respectful greeting (like Namaste).
  2. **The Observation**: (Gently explain what you see in the crop)
  3. **The Solution**: (Clear, simple steps for the farmer)
  4. **Advice**: (A simple tip and advice to visit an agricultural office if needed)
  
  Use simple words. Avoid complex science terms. Be encouraging.`;

  const imagePart = {
    inlineData: {
      data: base64Image,
      mimeType: "image/jpeg",
    },
  };

  const response = await ai.models.generateContent({
    model,
    contents: { parts: [imagePart, { text: prompt }] },
  });

  return response.text;
}

export async function askAgriQuestion(question: string, language: string = "English") {
  const model = "gemini-3-flash-preview";
  const prompt = `You are Krushi Mitra AI, a very helpful and polite rural agricultural assistant. 
  The farmer is asking: "${question}"
  
  Respond ONLY in ${language} (use the script for Hindi or Kannada). 
  Keep the answer very short (max 3 sentences), polite, and practical. 
  
  If the farmer asks about government schemes or financial help:
  - Mention specific Indian schemes like PM-KISAN, Fasal Bima Yojana, or Kisan Credit Card if relevant.
  - Explain the main benefit simply.
  - Always encourage them to visit the 'Schemes' section in this app for direct links.
  
  If they ask about crop health, give simple advice. 
  Use respectful greetings like 'Namaste' or 'Namaskara'.`;

  const response = await ai.models.generateContent({
    model,
    contents: prompt,
  });

  return response.text;
}
