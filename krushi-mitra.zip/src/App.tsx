/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useRef } from "react";
import { 
  Camera, 
  Mic, 
  CloudSun, 
  Building2, 
  Home, 
  ChevronDown, 
  MapPin, 
  Leaf,
  Scan,
  Menu,
  X,
  History,
  LogOut,
  ChevronRight,
  TrendingUp,
  Wind,
  Droplets,
  Thermometer,
  ShieldCheck,
  Zap,
  Info,
  ExternalLink,
  Search
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { GoogleAuthProvider, signInWithPopup, onAuthStateChanged, signOut, User } from "firebase/auth";
import { collection, addDoc, query, where, orderBy, onSnapshot, serverTimestamp, limit } from "firebase/firestore";
import Markdown from "react-markdown";
import { translations } from "./translations";
import { auth, db } from "./lib/firebase";
import { analyzeCrop, askAgriQuestion } from "./services/geminiService";

// Fix for TypeScript recognition window
declare global {
  interface Window {
    webkitSpeechRecognition: any;
    SpeechRecognition: any;
  }
}

interface ScanRecord {
  id: string;
  analysis: string;
  createdAt: any;
  userId: string;
}

const ActionCard = ({ 
  icon: Icon, 
  label, 
  bgColor,
  iconColor = "text-white",
  delay = 0,
  onClick
}: { 
  icon: any, 
  label: string, 
  bgColor: string,
  iconColor?: string,
  delay?: number,
  onClick?: () => void
}) => {
  return (
    <motion.button
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay, type: "spring", stiffness: 260, damping: 20 }}
      whileTap={{ scale: 0.9 }}
      onClick={onClick}
      className="flex flex-col items-center justify-center p-3 rounded-[28px] card-glass group h-28 transition-all"
    >
      <div className={`mb-2 w-10 h-10 rounded-full ${bgColor} flex items-center justify-center shadow-lg transition-transform group-hover:scale-110`}>
        <Icon className={`w-5 h-5 ${iconColor}`} strokeWidth={2.5} />
      </div>
      <span className="font-display font-black text-[9px] tracking-widest uppercase text-white/70">{label}</span>
    </motion.button>
  );
};

export default function App() {
  const [activeTab, setActiveTab] = useState("Home");
  const [language, setLanguage] = useState("English");
  const [user, setUser] = useState<User | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [scanResult, setScanResult] = useState<string | null>(null);
  const [scanHistory, setScanHistory] = useState<ScanRecord[]>([]);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [voiceAnswer, setVoiceAnswer] = useState<string | null>(null);
  const [isSchemeQuery, setIsSchemeQuery] = useState(false);
  const [schemeSearch, setSchemeSearch] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);

  const t = translations[language as keyof typeof translations] || translations.English;

  useEffect(() => {
    const loadVoices = () => {
      const v = window.speechSynthesis.getVoices();
      if (v.length > 0) setVoices(v);
    };
    loadVoices();
    window.speechSynthesis.onvoiceschanged = loadVoices;
  }, []);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (u) => {
      setUser(u);
    });
    return unsub;
  }, []);

  useEffect(() => {
    if (user) {
      const q = query(
        collection(db, "scans"),
        where("userId", "==", user.uid),
        orderBy("createdAt", "desc"),
        limit(activeTab === "History" ? 20 : 3)
      );
      const unsub = onSnapshot(q, (snap) => {
        const docs = snap.docs.map(d => ({ id: d.id, ...d.data() } as ScanRecord));
        // Ensure uniqueness if for some reason snapshots overlap
        setScanHistory(prev => {
          const combined = [...docs];
          const unique = combined.filter((v, i, a) => a.findIndex(t => t.id === v.id) === i);
          return unique;
        });
      }, (err) => {
        console.error("Firestore snapshot error:", err);
      });
      return unsub;
    } else {
      setScanHistory([]);
    }
  }, [user, activeTab]);

  const handleLogin = async () => {
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
    } catch (err) {
      console.error("Login failed:", err);
    }
  };

  const handleLogout = () => {
    signOut(auth);
    setActiveTab("Home");
  };

  const handleSpeak = (text: string) => {
    if ("speechSynthesis" in window) {
      window.speechSynthesis.cancel();
      
      const cleanText = text
        .replace(/\*\*/g, "")
        .replace(/###/g, ". . ")
        .replace(/##/g, ". . ")
        .replace(/#/g, "")
        .replace(/\n\n/g, ". . . ")
        .replace(/\n/g, ". ")
        .replace(/-/g, " ");

      const utterance = new SpeechSynthesisUtterance(cleanText);
      
      // Precise language code mapping
      let langCode = "en-IN";
      let voiceSearchTerms = ["google", "female", "india"];

      if (language === "ಕನ್ನಡ") {
        langCode = "kn-IN";
        voiceSearchTerms = ["kannada", "google", "female"];
      } else if (language === "हिंदी") {
        langCode = "hi-IN";
        voiceSearchTerms = ["hindi", "google", "female"];
      }

      utterance.lang = langCode;

      // Find the best voice from our state
      const nativeVoice = voices.find(v => 
        (v.lang.toLowerCase().replace("_", "-") === langCode.toLowerCase() || v.lang.startsWith(langCode.split("-")[0])) && 
        voiceSearchTerms.some(term => v.name.toLowerCase().includes(term))
      ) || voices.find(v => v.lang.toLowerCase().replace("_", "-") === langCode.toLowerCase() || v.lang.startsWith(langCode.split("-")[0]));

      if (nativeVoice) {
        utterance.voice = nativeVoice;
      }

      utterance.rate = 0.9;
      utterance.pitch = 1.1; // Slightly warmer/friendly pitch
      utterance.volume = 1;

      utterance.onstart = () => setIsSpeaking(true);
      utterance.onend = () => setIsSpeaking(false);
      utterance.onerror = () => setIsSpeaking(false);
      
      window.speechSynthesis.speak(utterance);
    }
  };

  const startListening = () => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert("Voice recognition not supported in this browser.");
      return;
    }

    if (!user) {
      handleLogin();
      return;
    }

    stopSpeaking();
    setVoiceAnswer(null);
    setTranscript("");
    
    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    
    if (language === "ಕನ್ನಡ") recognition.lang = "kn-IN";
    else if (language === "हिंदी") recognition.lang = "hi-IN";
    else recognition.lang = "en-IN";

    recognition.onstart = () => {
      setIsListening(true);
    };

    recognition.onresult = async (event: any) => {
      const text = event.results[0][0].transcript;
      setTranscript(text);
      setIsListening(false);
      
      // Get AI response
      const answer = await askAgriQuestion(text, language);
      setVoiceAnswer(answer);
      handleSpeak(answer);
      
      const isSchemeRelated = text.toLowerCase().includes("scheme") || 
                             text.toLowerCase().includes("yojana") || 
                             text.toLowerCase().includes("योजना") || 
                             text.toLowerCase().includes("ಯೋಜನೆ") ||
                             text.toLowerCase().includes("loan") ||
                             text.toLowerCase().includes("paisa") ||
                             text.toLowerCase().includes("ಹಣ") ||
                             text.toLowerCase().includes("ಸಾಲ");
      
      setIsSchemeQuery(isSchemeRelated);
      if (isSchemeRelated) {
        setSchemeSearch(text.split(" ").slice(-2).join(" ")); // Basic keyword extraction
      }
    };

    recognition.onerror = (event: any) => {
      console.error("Speech recognition error", event.error);
      setIsListening(false);
    };

    recognition.onend = () => {
      setIsListening(false);
    };

    recognition.start();
  };

  const handleNearbySearch = () => {
    const query = encodeURIComponent("Agricultural office or Crop care center near me");
    window.open(`https://www.google.com/maps/search/${query}`, "_blank");
  };

  const stopSpeaking = () => {
    window.speechSynthesis.cancel();
    setIsSpeaking(false);
  };

  useEffect(() => {
    if (activeTab === "Voice") {
      startListening();
    } else {
      stopSpeaking();
    }
  }, [activeTab]);

  const handleScanClick = () => {
    if (!user) {
      handleLogin();
      return;
    }
    fileInputRef.current?.click();
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;

    setIsScanning(true);
    setScanResult(null);

    try {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64 = (reader.result as string).split(",")[1];
        const analysis = await analyzeCrop(base64, language);
        setScanResult(analysis);

        await addDoc(collection(db, "scans"), {
          userId: user.uid,
          analysis,
          createdAt: serverTimestamp(),
        });

        setIsScanning(false);
      };
      reader.readAsDataURL(file);
    } catch (err) {
      console.error("Scanning failed:", err);
      setIsScanning(false);
    }
  };

  return (
    <div className="h-screen bg-natural-950 flex flex-col overflow-hidden relative text-white font-sans">
      <input 
        type="file" 
        accept="image/*" 
        className="hidden" 
        ref={fileInputRef} 
        onChange={handleFileChange}
      />

      <div className="fixed inset-0 z-0 bg-[radial-gradient(circle_at_50%_40%,#1b4332_0%,#051a0d_100%)]" />
      
      <div className="fixed top-20 left-[-5%] opacity-[0.03] z-0 pointer-events-none leaf-float">
        <Leaf className="w-64 h-64 rotate-12" />
      </div>
      <div className="fixed bottom-40 right-[-5%] opacity-[0.02] z-0 pointer-events-none leaf-float" style={{ animationDelay: "2s" }}>
        <Leaf className="w-72 h-72 -rotate-12" />
      </div>

      <header className="relative z-20 px-6 pt-10 pb-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-full bg-[#4ade80]/10 border border-[#4ade80]/20 flex items-center justify-center shadow-[0_0_15px_rgba(74,222,128,0.1)]">
             <div className="w-6 h-6 bg-[#4ade80] rounded-full flex items-center justify-center">
               <Leaf className="w-3.5 h-3.5 text-natural-950" />
             </div>
          </div>
          <div>
            <h1 className="font-display text-base font-bold tracking-tight text-white leading-tight">{t.title}</h1>
            <div className="flex items-center gap-1 opacity-70 cursor-pointer" onClick={user ? undefined : handleLogin}>
              <div className={`w-1 h-1 rounded-full ${user ? "bg-green-400 animate-pulse" : "bg-gray-500"}`} />
              <span className="text-[9px] uppercase font-bold tracking-widest text-green-400/80">
                {user ? user.displayName?.split(" ")[0] : t.login}
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {user && (
            <button 
              onClick={() => setActiveTab(activeTab === "History" ? "Home" : "History")}
              className={`p-2 rounded-full border border-white/5 backdrop-blur-md transition-colors ${activeTab === "History" ? "bg-white/20" : "bg-white/5"}`}
            >
              <History className="w-4 h-4 text-white/60" />
            </button>
          )}
          
          <motion.button 
            whileTap={{ scale: 0.95 }}
            onClick={() => setLanguage(l => l === "English" ? "ಕನ್ನಡ" : l === "ಕನ್ನಡ" ? "हिंदी" : "English")}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-[#facc15] text-[#041208] rounded-xl font-bold text-[10px] shadow-lg shadow-yellow-500/10"
          >
             <span className="font-black text-[12px]">अ</span>
             <span>{language === "ಕನ್ನಡ" ? "ಕನ್ನಡ" : language === "हिंदी" ? "हिंदी" : "English"}</span>
          </motion.button>
        </div>
      </header>

      <main className="relative z-10 flex-1 px-6 pt-2 pb-28 max-w-md mx-auto w-full overflow-y-auto no-scrollbar">
        <AnimatePresence mode="wait">
          {activeTab === "Home" && (
            <motion.div
              key="home"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-6"
            >
              <section className="flex flex-col items-center text-center pt-2">
                <div className="relative mb-4">
                  <div className="w-16 h-16 rounded-full bg-[#facc15] flex items-center justify-center shadow-2xl shadow-yellow-500/20 transform hover:scale-105 transition-transform">
                     <Leaf className="w-8 h-8 text-[#041208]" strokeWidth={2.5} />
                  </div>
                  <motion.div 
                    animate={{ rotate: [0, 15, -15, 0] }}
                    transition={{ repeat: Infinity, duration: 4 }}
                    className="absolute -top-1 -right-1 text-lg"
                  >
                    🌱
                  </motion.div>
                </div>
                <h2 className="font-serif text-[22px] font-bold mb-0.5 tracking-tight text-white leading-tight">
                  {t.welcome}
                </h2>
                <p className="text-white/40 text-[9px] font-black uppercase tracking-[0.2em] mb-2">{t.subtitle}</p>
                <p className="text-[13px] text-white/50 font-medium italic max-w-[200px]">
                  {t.description}
                </p>
              </section>

              <section>
                <div className="flex justify-between items-center mb-4 px-1">
                  <h3 className="font-display text-[10px] font-black uppercase tracking-[0.1em] text-white/40">{t.quickTools}</h3>
                  <div className="flex items-center gap-1.5 px-2 py-0.5 bg-white/5 rounded-full border border-white/5">
                    <Zap className="w-2h-2 text-blue-400" />
                    <span className="text-[8px] font-black uppercase tracking-widest text-blue-300">AI</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 pb-2">
                  <ActionCard icon={Camera} label={t.cropScan} bgColor="bg-[#22c55e]" delay={0} onClick={handleScanClick} />
                  <ActionCard icon={Mic} label={t.voiceAi} bgColor="bg-[#78350f]" delay={0.05} onClick={() => setActiveTab("Voice")} />
                  <ActionCard icon={CloudSun} label={t.weather} bgColor="bg-[#fbbf24]" delay={0.1} onClick={() => setActiveTab("Weather")} />
                  <ActionCard icon={MapPin} label={t.cropCare} bgColor="bg-blue-600" delay={0.12} onClick={handleNearbySearch} />
                  <ActionCard icon={Building2} label={t.schemes} bgColor="bg-white/10" iconColor="text-white" delay={0.15} onClick={() => setActiveTab("Schemes")} />
                </div>
              </section>

              {user && scanHistory.length > 0 && (
                <section className="pb-4">
                  <div className="flex justify-between items-center mb-3 px-1">
                    <h3 className="font-display text-[10px] font-black uppercase tracking-[0.1em] text-white/40">{t.history}</h3>
                    <button className="text-[9px] font-bold text-green-400 uppercase" onClick={() => setActiveTab("History")}>{t.viewAll}</button>
                  </div>
                  <div className="space-y-2">
                    {scanHistory.map((scan, i) => (
                      <motion.div 
                        key={scan.id} 
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: i * 0.05 }}
                        onClick={() => setScanResult(scan.analysis)}
                        className="p-3 rounded-2xl bg-white/5 border border-white/5 flex items-center justify-between active:bg-white/10"
                      >
                        <div className="flex items-center gap-2.5">
                          <div className="w-8 h-8 rounded-lg bg-green-500/10 flex items-center justify-center flex-shrink-0">
                            <ShieldCheck className="w-4 h-4 text-green-400" />
                          </div>
                          <div className="min-w-0">
                            <p className="text-[10px] font-bold text-white/80 truncate leading-none mb-1">
                              {scan.analysis.substring(0, 40)}...
                            </p>
                            <p className="text-[8px] text-white/40 uppercase font-black">
                              {scan.createdAt?.seconds ? new Date(scan.createdAt.seconds * 1000).toLocaleDateString() : "Pending..."}
                            </p>
                          </div>
                        </div>
                        <ChevronRight className="w-3.5 h-3.5 text-white/20" />
                      </motion.div>
                    ))}
                  </div>
                </section>
              )}
            </motion.div>
          )}

          {activeTab === "History" && (
            <motion.div
              key="history"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-4"
            >
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-xl font-bold">{t.viewAll}</h3>
                {user && (
                   <button onClick={handleLogout} className="flex items-center gap-2 text-[10px] uppercase font-black text-red-400">
                     <LogOut className="w-3 h-3" /> {t.logout}
                   </button>
                )}
              </div>
              <div className="space-y-3">
                {scanHistory.length === 0 ? (
                  <div className="py-20 text-center opacity-30 italic text-sm">No scans found yet.</div>
                ) : (
                  scanHistory.map((scan) => (
                    <div 
                      key={scan.id} 
                      onClick={() => setScanResult(scan.analysis)}
                      className="p-4 rounded-3xl bg-white/5 border border-white/5 space-y-2 active:bg-white/10 transition-colors"
                    >
                      <div className="flex justify-between items-start">
                        <span className="text-[9px] font-black uppercase tracking-widest text-[#4ade80]">DIAGNOSED</span>
                        <span className="text-[9px] text-white/40 uppercase font-bold">
                          {scan.createdAt?.seconds ? new Date(scan.createdAt.seconds * 1000).toLocaleTimeString() : "Pending"}
                        </span>
                      </div>
                      <p className="text-xs text-white/70 line-clamp-2 leading-relaxed">{scan.analysis}</p>
                    </div>
                  ))
                )}
              </div>
            </motion.div>
          )}

          {activeTab === "Weather" && (
            <motion.div key="weather" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
              <div className="text-center py-2">
                <CloudSun className="w-12 h-12 text-yellow-400 mx-auto mb-2" />
                <h3 className="text-2xl font-bold">32°C</h3>
                <p className="text-white/50 text-xs">{t.weatherSunny} • Bagalkot, KA</p>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <WeatherInfo icon={Wind} label={t.weatherWind} value="12 km/h" />
                <WeatherInfo icon={Droplets} label={t.weatherHumid} value="45%" />
                <WeatherInfo icon={Thermometer} label="UV Index" value="High" />
                <WeatherInfo icon={TrendingUp} label={t.weatherRain} value="10%" />
              </div>
            </motion.div>
          )}

          {activeTab === "Schemes" && (
             <motion.div key="schemes" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-4 pt-2">
               <div className="flex items-center justify-between mb-2">
                 <h3 className="text-lg font-bold">{t.schemesTitle}</h3>
                 <div className="px-2 py-0.5 bg-green-500/10 border border-green-500/20 rounded-full">
                    <span className="text-[8px] font-black text-green-400 uppercase tracking-widest">Govt Portals</span>
                 </div>
               </div>

               {/* Manual Search Bar */}
               <div className="relative mb-4">
                 <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
                 <input 
                   type="text"
                   placeholder="Search schemes..."
                   value={schemeSearch}
                   onChange={(e) => setSchemeSearch(e.target.value)}
                   className="w-full bg-white/5 border border-white/10 rounded-2xl py-3 pl-11 pr-4 text-[13px] text-white focus:outline-none focus:border-green-500/50 transition-all"
                 />
                 {schemeSearch && (
                   <button onClick={() => setSchemeSearch("")} className="absolute right-4 top-1/2 -translate-y-1/2 text-[10px] font-bold text-white/30">Clear</button>
                 )}
               </div>

               <div className="space-y-3">
                 {((t as any).schemesList || [])
                    .filter((s: any) => 
                      !schemeSearch || 
                      s.title.toLowerCase().includes(schemeSearch.toLowerCase()) || 
                      s.desc.toLowerCase().includes(schemeSearch.toLowerCase()) ||
                      s.tag.toLowerCase().includes(schemeSearch.toLowerCase())
                    )
                    .map((scheme: any, i: number) => (
                   <SchemeCard 
                    key={i}
                    title={scheme.title} 
                    desc={scheme.desc} 
                    url={scheme.url}
                    tag={scheme.tag}
                   />
                 ))}
                 
                 {schemeSearch && ((t as any).schemesList || []).filter((s: any) => 
                    s.title.toLowerCase().includes(schemeSearch.toLowerCase()) || 
                    s.desc.toLowerCase().includes(schemeSearch.toLowerCase())
                 ).length === 0 && (
                   <div className="py-10 text-center">
                     <p className="text-sm text-white/30 italic">No specific scheme found for "{schemeSearch}"</p>
                     <button onClick={() => setSchemeSearch("")} className="mt-2 text-xs font-bold text-green-400 uppercase tracking-widest">Show All</button>
                   </div>
                 )}
               </div>
               
               <div className="mt-8 p-5 rounded-[32px] bg-gradient-to-br from-green-500/10 to-blue-500/5 border border-white/5 shadow-xl">
                  <div className="flex items-center gap-2 mb-3">
                    <Info className="w-4 h-4 text-green-400" />
                    <h4 className="text-[10px] font-black uppercase text-white/60 tracking-widest">{t.supportedCrops}</h4>
                  </div>
                  <p className="text-[12px] text-white/50 leading-relaxed font-medium">
                    Our AI is updated to support: <span className="text-white/80">Cotton, Rice, Wheat, Maize, Chili, Soybean, Sugarcane, and Tomato.</span>
                  </p>
                  <p className="mt-3 text-[10px] text-white/30 italic">
                    New schemes are updated every Sunday.
                  </p>
               </div>
             </motion.div>
          )}

          {activeTab === "Voice" && (
            <motion.div key="voice" initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="flex flex-col items-center py-6 min-h-[300px]">
              <div className="flex-1 flex flex-col items-center justify-center text-center">
                <button 
                  onClick={startListening}
                  className={`w-24 h-24 rounded-full flex items-center justify-center mb-6 relative transition-all ${isListening ? "bg-red-500/20 border-red-500/40" : "bg-white/5 border-white/10"}`}
                >
                  {isListening && (
                    <motion.div 
                      animate={{ scale: [1, 1.4, 1], opacity: [0.3, 0.1, 0.3] }} 
                      transition={{ repeat: Infinity, duration: 1.5 }} 
                      className="absolute inset-0 rounded-full bg-red-400" 
                    />
                  )}
                  <Mic className={`w-8 h-8 ${isListening ? "text-red-500 animate-pulse" : "text-white/40"}`} />
                </button>
                <p className="text-base font-bold text-white mb-1">
                  {isListening ? t.listening : transcript || t.askAdvice}
                </p>
                {isListening && (
                  <p className="text-[10px] text-white/40 uppercase font-black tracking-widest animate-pulse">Krushi Mitra is hearing...</p>
                )}
              </div>

              <AnimatePresence>
                {voiceAnswer && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }} 
                    animate={{ opacity: 1, y: 0 }}
                    className="mt-6 w-full p-5 rounded-3xl bg-white/5 border border-white/10 shadow-xl"
                  >
                    <div className="flex items-center gap-2 mb-3">
                       <Zap className="w-3.5 h-3.5 text-yellow-400" />
                       <span className="text-[10px] font-black tracking-widest uppercase text-white/40">AI Response</span>
                    </div>
                    <div className="text-[13px] text-white/80 leading-relaxed font-medium">
                      <Markdown>{voiceAnswer}</Markdown>
                    </div>
                    
                    {isSchemeQuery && (
                      <button 
                        onClick={() => {
                          setActiveTab("Schemes");
                          stopSpeaking();
                        }}
                        className="mt-4 w-full py-2.5 rounded-xl flex items-center justify-center gap-2 bg-green-500 text-black font-black uppercase text-[10px] tracking-widest shadow-lg shadow-green-500/20"
                      >
                         <Building2 className="w-3.5 h-3.5" />
                         Check Official Schemes
                      </button>
                    )}
                    
                    <button 
                      onClick={() => isSpeaking ? stopSpeaking() : handleSpeak(voiceAnswer)}
                      className={`mt-4 w-full py-2.5 rounded-xl flex items-center justify-center gap-2 border transition-all ${isSpeaking ? "bg-red-500/10 border-red-500/20 text-red-500" : "bg-[#4ade80]/10 border-[#4ade80]/20 text-[#4ade80]"}`}
                    >
                      <Mic className={`w-3.5 h-3.5 ${isSpeaking ? "animate-pulse" : ""}`} />
                      <span className="text-[10px] font-bold uppercase tracking-wider">{isSpeaking ? t.stopReading : t.readAloud}</span>
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      <nav className="fixed bottom-0 left-0 right-0 z-40 bg-natural-900/90 backdrop-blur-xl px-10 py-3 flex justify-between items-center border-t border-white/5 pb-8">
        <NavIcon icon={Home} label={t.navHome} active={activeTab === "Home"} onClick={() => setActiveTab("Home")} />
        <NavIcon icon={Mic} label={t.navVoice} active={activeTab === "Voice"} onClick={() => setActiveTab("Voice")} />
        <div className="relative">
          <motion.button whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }} onClick={handleScanClick} className="w-12 h-12 rounded-full floating-scan-btn flex items-center justify-center -translate-y-8 border-[4px] border-natural-900 shadow-xl">
            <Scan className="w-5 h-5 text-white" strokeWidth={3} />
          </motion.button>
          <div className="absolute -bottom-1 left-1/2 -translate-x-1/2">
             <span className="text-[8px] font-black text-[#4ade80] tracking-widest">{t.navScan}</span>
          </div>
        </div>
        <NavIcon icon={CloudSun} label={t.navWeather} active={activeTab === "Weather"} onClick={() => setActiveTab("Weather")} />
        <NavIcon icon={Building2} label={t.navScheme} active={activeTab === "Schemes"} onClick={() => setActiveTab("Schemes")} />
      </nav>

      <AnimatePresence>
        {isScanning && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex flex-col items-center justify-center p-10 text-center">
            <div className="w-40 h-40 border-2 border-[#4ade80] rounded-3xl relative overflow-hidden mb-8">
              <motion.div animate={{ top: ["-10%", "110%"] }} transition={{ repeat: Infinity, duration: 1.5 }} className="absolute left-0 right-0 h-1 bg-[#4ade80] shadow-[0_0_15px_#4ade80]" />
              <Scan className="w-full h-full p-10 text-[#4ade80]/20" />
            </div>
            <h3 className="text-xl font-bold mb-2">{t.analyzing}</h3>
            <p className="text-white/50 text-xs">{t.description}</p>
          </motion.div>
        )}

        {scanResult && (
          <motion.div initial={{ opacity: 0, y: 100 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 100 }} className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-end justify-center p-4">
            <div className="bg-natural-900 w-full max-w-sm rounded-[32px] border border-white/10 shadow-2xl overflow-hidden max-h-[80vh] flex flex-col">
              <div className="p-5 border-b border-white/5 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <ShieldCheck className="w-5 h-5 text-green-400" />
                  <h4 className="text-sm font-bold uppercase tracking-tight">{t.diagnosticResult}</h4>
                </div>
                <button onClick={() => { setScanResult(null); stopSpeaking(); }} className="p-1.5 bg-white/5 rounded-full"><X className="w-4 h-4" /></button>
              </div>
              <div className="p-6 overflow-y-auto no-scrollbar flex-1 bg-[radial-gradient(circle_at_top_right,rgba(74,222,128,0.05),transparent)]">
                <div className="markdown-body text-[13px] text-white/80 leading-relaxed font-medium mb-6">
                  <Markdown>{scanResult}</Markdown>
                </div>
                
                <button 
                  onClick={() => isSpeaking ? stopSpeaking() : handleSpeak(scanResult || "")}
                  className={`w-full py-3 rounded-2xl flex items-center justify-center gap-2 border transition-all ${isSpeaking ? "bg-red-500/10 border-red-500/20 text-red-500" : "bg-white/5 border-white/10 text-white"}`}
                >
                  <Mic className={`w-4 h-4 ${isSpeaking ? "animate-pulse" : ""}`} />
                  <span className="text-[11px] font-bold">{isSpeaking ? t.stopReading : t.readAloud}</span>
                </button>

                <button 
                  onClick={handleNearbySearch}
                  className="w-full mt-3 py-3 rounded-2xl flex items-center justify-center gap-2 bg-blue-500/10 border border-blue-500/20 text-blue-400 text-[11px] font-bold"
                >
                  <MapPin className="w-4 h-4" />
                  {t.findNearby}
                </button>
              </div>
              <div className="p-4 bg-white/5">
                <button className="w-full py-3 bg-[#4ade80] text-[#041208] rounded-2xl font-bold text-xs" onClick={() => { setScanResult(null); stopSpeaking(); }}>{t.gotIt}</button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

const NavIcon = ({ icon: Icon, label, active, onClick }: { icon: any, label: string, active: boolean, onClick: () => void }) => (
  <motion.button onClick={onClick} className={`relative flex flex-col items-center gap-0.5 transition-colors ${active ? "text-[#FBC02D]" : "text-white/30 hover:text-white/50"}`}>
    <Icon className="w-5 h-5" strokeWidth={active ? 2.5 : 2} />
    <span className="text-[7px] font-black tracking-[0.1em] uppercase">{label}</span>
  </motion.button>
);

const WeatherInfo = ({ icon: Icon, label, value }: { icon: any, label: string, value: string }) => (
  <div className="p-3 rounded-2xl bg-white/5 border border-white/5 flex flex-col items-center justify-center text-center">
    <Icon className="w-4 h-4 text-white/30 mb-1" />
    <p className="text-[7px] font-black uppercase text-white/20">{label}</p>
    <p className="text-xs font-bold text-white/90">{value}</p>
  </div>
);

const SchemeCard = ({ title, desc, url, tag }: { title: string, desc: string, url: string, tag: string }) => (
  <motion.div 
    whileHover={{ scale: 1.02 }}
    whileTap={{ scale: 0.98 }}
    onClick={() => window.open(url, "_blank")}
    className="p-4 rounded-2xl bg-white/5 border border-white/5 flex flex-col gap-2 active:bg-white/10 transition-all cursor-pointer relative overflow-hidden group"
  >
    <div className="absolute top-0 right-0 p-2 opacity-0 group-hover:opacity-100 transition-opacity">
      <ExternalLink className="w-3 h-3 text-white/40" />
    </div>
    <div className="flex items-center justify-between">
      <h4 className="font-bold text-[13px] text-[#4ade80]">{title}</h4>
      <span className="text-[8px] font-black uppercase tracking-widest text-white/30 bg-white/5 px-2 py-0.5 rounded-full border border-white/5">{tag}</span>
    </div>
    <p className="text-[11px] text-white/50 leading-relaxed">{desc}</p>
  </motion.div>
);


